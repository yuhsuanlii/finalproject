package detailsources;

public interface FoodDataDAO {
	public abstract FoodDataBean select(Integer sampleid);

}