package tw.com.finalproj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IkcApplication {

	public static void main(String[] args) {
		SpringApplication.run(IkcApplication.class, args);
	}

}
