package tw.com.finalproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IkcApplicationTests {

	@Test
	void contextLoads() {
	}

}
